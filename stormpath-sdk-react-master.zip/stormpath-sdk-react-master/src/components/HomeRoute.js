import { Route } from 'react-router';

export default class HomeRoute extends Route {
}
