import keyMirror from 'keymirror';

export default keyMirror({
  TOKEN_SET: null,
  TOKEN_REFRESH: null
});
